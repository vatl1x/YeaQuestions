import { useEffect, useRef } from "react";
import hljs from "highlight.js";
import "highlight.js/styles/atom-one-dark.css";
import styles from "./HtmlContent.module.scss";

interface Props {
  html: string;
}

const HtmlContent = ({ html }: Props) => {
  const ref = useRef<HTMLDivElement>(null);

  //подсветка кода
  useEffect(() => {
    ref.current?.querySelectorAll("pre code").forEach((block) => {
      hljs.highlightElement(block as HTMLElement);  
    });
  }, [html]);

  return (
    <div
      ref={ref}
      className={styles.htmlContent}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
};

export default HtmlContent;
