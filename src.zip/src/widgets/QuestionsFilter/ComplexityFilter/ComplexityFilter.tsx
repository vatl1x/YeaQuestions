import { useFilters } from "../../../context/FiltersContext";
import Skeleton from "../../../ui/Skeleton/Skeleton";
import ButtonFilter from "../../../ui/ButtonFilter/ButtonFilter";
import { COMPLEXITY_RANGES } from "./complexityFilter.constants";

import styles from "./ComplexityFilter.module.scss";

const ComplexityFilter = () => {
    const { filters, setFilters, isQuestionsLoading } = useFilters();
    const toggleComplexity = (complexityValues: number[]) => {
        setFilters((prev) => {
            const currentComplexity = prev.complexity ?? [];

            const isActive = complexityValues.some((value) =>
                currentComplexity?.includes(value),
            );

            return {
                ...prev,
                complexity: isActive
                    ? currentComplexity.filter(
                          (value) => !complexityValues?.includes(value),
                      )
                    : [...currentComplexity, ...complexityValues],
            };
        });
    };
    return (
        <div className={styles.filterGroup}>
            {isQuestionsLoading ? (
                <>
                    <Skeleton
                        type="text"
                        width="115px"
                        height="20px"
                        borderRadius="5px"
                    />
                    <Skeleton
                        type="button"
                        count={4}
                        direction="row"
                        width="50px"
                    />
                </>
            ) : (
                <>
                    <span className={styles.label}>Сложность</span>
                    <div className={styles.button}>
                        {COMPLEXITY_RANGES.map((item) => (
                            <ButtonFilter
                                key={item.label}
                                title={item.label}
                                isActive={item.values.some((value) =>
                                    filters.complexity?.includes(value),
                                )}
                                onClick={() => toggleComplexity(item.values)}
                            />
                        ))}
                    </div>{" "}
                </>
            )}
        </div>
    );
};

export default ComplexityFilter;
