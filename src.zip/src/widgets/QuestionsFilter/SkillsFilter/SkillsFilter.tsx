import ButtonFilter from "../../../ui/ButtonFilter/ButtonFilter";

import styles from "./SkillsFilter.module.scss";
import { useSkills } from "../../../hooks/useSkills";
import { useState } from "react";
import { useFilters } from "../../../context/FiltersContext";
import Skeleton from "../../../ui/Skeleton/Skeleton";
const SkillsFilter = () => {
    const { filters, setFilters } = useFilters();
    const { skills, isLoading, error } = useSkills();
    const [isOpen, setIsOpen] = useState(false);
    const sortedSkills = skills?.sort((a, b) => a.id - b.id);
    const visibleSkills = isOpen ? sortedSkills : sortedSkills?.slice(0, 5);
    const toggleSkills = (id: number) => {
        setFilters((prev) => {
            const currentSkills = prev.skills ?? [];
            const isActive = currentSkills.includes(id);

            return {
                ...prev,
                skills: isActive
                    ? currentSkills.filter((itemId) => itemId !== id)
                    : [...currentSkills, id],
            };
        });
    };
    return (
        <div className={styles.filterGroup}>
            {isLoading ? (
                <>
                    <Skeleton
                        type="text"
                        width="115px"
                        height="20px"
                        borderRadius="5px"
                    />
                    <Skeleton type="button" count={5} direction="row" />
                    <Skeleton
                        type="text"
                        width="115px"
                        height="20px"
                        borderRadius="10px"
                    />
                </>
            ) : error ? (
                <div className={styles.error}>{error}</div>
            ) : (
                <>
                    <span className={styles.label}>Выберите навыки</span>
                    <div className={styles.button}>
                        {visibleSkills?.map((item) => (
                            <ButtonFilter
                                key={item.id}
                                title={item.title}
                                icon={item.imageSrc}
                                isActive={filters.skills?.includes(item.id)}
                                onClick={() => toggleSkills(item.id)}
                            />
                        ))}
                    </div>
                    {(skills?.length ?? 0) > 5 && (
                        <button
                            className={styles.showAll}
                            onClick={() => setIsOpen((prev) => !prev)}
                        >
                            {isOpen ? "Скрыть" : "Просмотреть все"}
                        </button>
                    )}
                </>
            )}
        </div>
    );
};

export default SkillsFilter;
