import { useFilters } from "../../../context/FiltersContext";
import Skeleton from "../../../ui/Skeleton/Skeleton";
import ButtonFilter from "../../../ui/ButtonFilter/ButtonFilter";
import styles from "./RatingFilter.module.scss";

const RatingFilter = () => {
    const { filters, setFilters, isQuestionsLoading } = useFilters();
    const toggleRate = (idx: number) => {
        setFilters((prev) => {
            const currentRate = prev.rate ?? [];
            const value = idx + 1;

            const isActive = currentRate.includes(value);

            return {
                ...prev,
                rate: isActive
                    ? currentRate.filter((rate) => rate !== value)
                    : [...currentRate, value],
            };
        });
    };
    return (
        <div className={styles.filterGroup}>
            {isQuestionsLoading ? (
                <>
                    <Skeleton type='text' width="115px" height="20px" borderRadius="5px" />
                    <Skeleton type='button' width="36px" height="36px"  count={5} direction="row"  />

                </>
            ) : (
                <>
                    <span className={styles.label}>Рейтинг</span>
                    <div className={styles.button}>
                        {[...Array(5)].map((_, idx) => (
                            <ButtonFilter
                                key={idx}
                                title={String(idx + 1)}
                                isActive={filters.rate?.includes(idx + 1)}
                                onClick={() => toggleRate(idx)}
                            />
                        ))}
                    </div>{" "}
                </>
            )}
        </div>
    );
};

export default RatingFilter;
