import ButtonFilter from "../../ui/ButtonFilter/ButtonFilter";

import styles from "./StatusFilter.module.scss";

const StatusFilter = () => {
    return (
        <div className={styles.filterGroup}>
            <span className={styles.label}>Рейтинг</span>
            <div className={styles.button}>
                <ButtonFilter title="Изученные" />
                <ButtonFilter title="Не изученные" />
                <ButtonFilter title="Все" />
            </div>
        </div>
    );
};

export default StatusFilter;
