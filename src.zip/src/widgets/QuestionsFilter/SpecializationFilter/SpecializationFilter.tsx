import ButtonFilter from "../../../ui/ButtonFilter/ButtonFilter";

import styles from "./SpecializationFilter.module.scss";
import { useSpecialization } from "../../../hooks/useSpecialization";
import { useState } from "react";
import { useFilters } from "../../../context/FiltersContext";
import Skeleton from "../../../ui/Skeleton/Skeleton";

const SpecializationFilter = () => {
    const { filters, setFilters } = useFilters();
    const { specializations, isLoading, error } = useSpecialization();
    const [isOpen, setIsOpen] = useState(false);

    const sortedSpecialization = specializations?.sort((a, b) => a.id - b.id);
    const visibleSpecialization = isOpen
        ? sortedSpecialization
        : sortedSpecialization?.slice(0, 5);

    const toggleSpecialization = (id: number, title: string) => {
        setFilters((prev) => {
            const isActive = prev.specializationId === id;

            return {
                ...prev,
                specializationTitle: isActive ? undefined : title,
                specializationId: isActive ? null : id,
                skills: [],
            };
        });
    };

    return (
        <div className={styles.filterGroup}>
            {isLoading ? (
                <>
                    <Skeleton
                        type="text"
                        width="110px"
                        height="20px"
                        borderRadius="5px"
                    />
                    <Skeleton type="button" count={5} direction="row" width="100%" />
                    <Skeleton
                        type="text"
                        width="115px"
                        height="20px"
                        borderRadius="10px"
                    />
                </>
            ) : error ? (
                <div className={styles.error}>{error}</div>
            ) : (
                <>
                    <span className={styles.label}>Специализация:</span>
                    <div className={styles.button}>
                        {visibleSpecialization?.map((item) => (
                            <ButtonFilter
                                key={item.id}
                                title={item.title}
                                isActive={filters.specializationId === item.id}
                                onClick={() =>
                                    toggleSpecialization(item.id, item.title)
                                }
                            />
                        ))}
                    </div>
                    {(specializations?.length ?? 0) > 5 && (
                        <button
                            className={styles.showAll}
                            onClick={() => setIsOpen((prev) => !prev)}
                        >
                            {isOpen ? "Скрыть" : "Просмотреть все"}
                        </button>
                    )}
                </>
            )}
        </div>
    );
};

export default SpecializationFilter;
