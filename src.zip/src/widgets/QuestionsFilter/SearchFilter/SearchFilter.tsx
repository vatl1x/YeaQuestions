import { useEffect, useState } from "react";
import { useFilters } from "../../../context/FiltersContext";
import { useDebounce } from "../../../hooks/useDebounce";
import search from "../../../assets/icons/search.svg";

import styles from "./SearchFilter.module.scss";
import Skeleton from "../../../ui/Skeleton/Skeleton";

const SearchFilter = () => {
    const [value, setValue] = useState("");
    const debounceValue = useDebounce(value, 1500);
    const { setFilters, isQuestionsLoading } = useFilters();

    useEffect(() => {
        setFilters((prev) => ({ ...prev, title: debounceValue }));
    }, [debounceValue]);

    return (
        <>
            {isQuestionsLoading ? (
                <Skeleton type="text" width="100%" height="50px" borderRadius="12px"/>
            ) : (
                <label className={styles.searchValue} aria-label="Поиск">
                    <img src={search} alt="" />
                    <input
                        type="text"
                        value={value}
                        placeholder="Введите текст"
                        className={styles.searchInput}
                        onChange={(e) => setValue(e.target.value)}
                    />
                </label>
            )}
        </>
    );
};

export default SearchFilter;
