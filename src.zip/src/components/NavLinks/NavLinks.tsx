import { NAV_LINKS } from "./navLinks.constants";
import clsx from "clsx";
import styles from "./NavLinks.module.scss";
import { NavLink } from "react-router-dom";

interface Props {
    variant?: "desktop" | "mobile";
}

const NavLinks = ({ variant = "desktop" }: Props) => {
    return (
        <div className={styles.navLinkList}>
            {NAV_LINKS.map((link) => (
                <NavLink
                    to={link.href}
                    key={link.label}
                    className={({ isActive }) =>
                        clsx(styles.navLink, {
                            [styles.navLinkMobile]: variant === "mobile",
                            [styles.navLinkActive] : isActive
                        })
                    }
                >
                    <span className={styles.navLinkText}>{link.label}</span>
                </NavLink>
            ))}
        </div>
    );
};

export default NavLinks;
