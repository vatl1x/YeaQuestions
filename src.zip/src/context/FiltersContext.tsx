import { createContext, useContext, useState, type ReactNode } from "react";
import { useLocation } from "react-router-dom";
import { toNumberArray, toPositiveNumber } from "../utils/QueryParams";

export interface IFilters {
    title?: string;
    specializationTitle?: string;
    specializationId?: number | null;
    skills?: number[];
    complexity?: number[];
    rate?: number[];
}

export interface IFiltersContext {
    filters: IFilters;
    setFilters: React.Dispatch<React.SetStateAction<IFilters>>;
    isQuestionsLoading: boolean;
    setIsQuestionsLoading: React.Dispatch<React.SetStateAction<boolean>>;
}

interface FiltersProviderProps {
    children: ReactNode;
}
const FiltersContext = createContext<IFiltersContext | undefined>(undefined);

export const useFilters = () => {
    const context = useContext(FiltersContext);
    if (!context) {
        throw new Error("context error");
    }
    return context;
};

export const FiltersProvider = ({ children }: FiltersProviderProps) => {
    const location = useLocation();
    const params = new URLSearchParams(location.search);

    const [filters, setFilters] = useState<IFilters>({
        title: params.get("title") ?? "",
        specializationId: toPositiveNumber(
            params.get("specializationId"),
            null,
        ),
        skills: toNumberArray(params.get("skills")),
        complexity: toNumberArray(params.get("complexity")),
        rate: toNumberArray(params.get("rate")),
    });
    const [isQuestionsLoading, setIsQuestionsLoading] = useState(false);

    return (
        <FiltersContext.Provider
            value={{
                filters,
                setFilters,
                isQuestionsLoading,
                setIsQuestionsLoading,
            }}
        >
            {children}
        </FiltersContext.Provider>
    );
};
