import { useEffect } from "react";
import { useFilters } from "../context/FiltersContext";
import { useQuestionsQuery } from "./useQuestionsQuery";

export const useQuerySync = (currentPage: number) => {
    const { setQuery } = useQuestionsQuery();
    const { filters } = useFilters();

    useEffect(() => {
        setQuery(filters, currentPage);
    }, [currentPage]);

    useEffect(() => {
        setQuery(filters, 1);
    }, [filters]);
};
