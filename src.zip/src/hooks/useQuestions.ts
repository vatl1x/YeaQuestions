import { useEffect, useState } from "react";
import { getQuestions } from "../api/questionsApi";
import type { QuestionApiResponse } from "../types/question";
import { useFilters } from "../context/FiltersContext";
import { useQuestionsQuery } from "./useQuestionsQuery";

export const useQuestions = () => {
    const { query, setQuery } = useQuestionsQuery();
    const [data, setData] = useState<QuestionApiResponse | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const { filters, setIsQuestionsLoading } = useFilters();

    const setCurrentPage = (page: number) => {
        setQuery(filters, page);
    };

    useEffect(() => {
        setIsLoading(true);
        (async () => {
            try {
                console.log(filters);
                const response = await getQuestions({
                    page: query.page,
                    ...filters,
                });
                setData(response);
            } catch (error) {
                setError(`Ошибка загрузки: ${error}`);
            } finally {
                setIsLoading(false);
            }
        })();
    }, [query.page, filters]);

    useEffect(() => {
        setIsQuestionsLoading(isLoading);
    }, [isLoading]);

    const { data: questions, total = 0, limit = 10 } = data ?? {};

    return {
        questions,
        total,
        limit,
        currentPage: query.page,
        setCurrentPage,
        isLoading,
        error,
    };
};
