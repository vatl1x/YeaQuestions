import { useLocation, useNavigate } from "react-router-dom";
import type { IFilters } from "../context/FiltersContext";
import { toNumberArray, toPositiveNumber } from "../utils/QueryParams";

export const useQuestionsQuery = () => {
    const location = useLocation();
    const params = new URLSearchParams(location.search);
    const navigate = useNavigate();

    const query = {
        page: toPositiveNumber(params.get("page"), 1),
        limit: toPositiveNumber(params.get("limit"), 10),
        title: params.get("title") ?? "",
        specializationId: toPositiveNumber(
            params.get("specializationId"),
            null,
        ),
        skills: toNumberArray(params.get("skills")),
        complexity: toNumberArray(params.get("complexity")),
        rate: toNumberArray(params.get("rate")),
    };

    const setQuery = (filters: IFilters, page: number) => {
        const params = new URLSearchParams();

        if (page > 1) {
            params.set("page", String(page));
        }
        if (filters.title) {
            params.set("title", filters.title);
        }
        if (filters.specializationId) {
            params.set("specializationId", String(filters.specializationId));
        }
        if (filters.skills?.length) {
            params.set("skills", filters.skills.join(","));
        }
        if (filters.complexity?.length) {
            params.set("complexity", filters.complexity.join(","));
        }
        if (filters.rate?.length) {
            params.set("rate", filters.rate.join(","));
        }

        navigate({ search: params.toString() }, { replace: true });
    };
    return { query, setQuery };
};
