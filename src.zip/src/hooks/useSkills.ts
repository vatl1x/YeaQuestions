import { useEffect, useState } from "react";
import type { SkillsApiResponse } from "../types/skill";
import { getSkills } from "../api/skillsApi";
import { useFilters } from "../context/FiltersContext";

export const useSkills = () => {
    const [data, setData] = useState<SkillsApiResponse | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const { filters } = useFilters();

    useEffect(() => {
        setIsLoading(true);
        (async () => {
            try {
                const response = await getSkills({
                    specializationId: filters.specializationId,
                });

                setData(response);
            } catch (error) {
                setError("Ошибка загрузки");
            } finally {
                setIsLoading(false);
            }
        })();
    }, [filters.specializationId]);

    const skills = data?.data;

    return { skills, isLoading, error };
};
