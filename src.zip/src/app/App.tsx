import { Outlet } from "react-router-dom";
import { FiltersProvider } from "../context/FiltersContext";
import Footer from "../widgets/Footer/Footer";
import Header from "../widgets/Header/Header";
import styles from "./App.module.scss";

function App() {
    return (
        <div className={styles.app}>
            <Header />
            <main className={styles.content}>
                <FiltersProvider>
                    <Outlet />
                </FiltersProvider>
            </main>

            <Footer />
        </div>
    );
}

export default App;
